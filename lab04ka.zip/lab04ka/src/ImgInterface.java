public interface ImgInterface {
    String getColor(String name, int x, int y);
}
