public class Main {
    public static void main(String[] args) {
        ConcreteImage img = new ConcreteImage();
        SecurityProxy proxy1=new SecurityProxy(0,5,0,5,img);
        SecurityProxy proxy2=new SecurityProxy(5,10,5,10,img);
        User user=new User();
        user.action(proxy1,"img1",2,2);
        System.out.println("Другий випадок: ");
        user.action(proxy2,"img2",2,2);
    }
}
