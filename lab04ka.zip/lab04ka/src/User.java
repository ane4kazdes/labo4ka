public class User {
    public void action(ImgInterface image,String name, int x, int y) {
        System.out.println("action() "+this);
        image.getColor(name, x, y);

    }
}
