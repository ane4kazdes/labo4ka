import java.awt.*;
import java.util.Random;

public class ConcreteImage implements ImgInterface {
    Random rnd=new Random();
    private String name;
    @Override
    public String getColor(String name, int x, int y) {
        this.name=name;
        System.out.println("getColor() "+this);
        return new Color(rnd.nextInt(255)).toString();
    }
}
