public class SecurityProxy implements ImgInterface {
    private int minX;
    private int maxX;
    private int minY;
    private int maxY;
    private ConcreteImage concreteImage;


    SecurityProxy(int minX, int maxX, int minY, int maxY, ConcreteImage concreteImage) {
        //У конструкторі ми, фактично, встановлюємо обмеження доступу для вхідної картинки (concreteImage)
        this.minX = minX;
        this.maxX = maxX;
        this.minY = minY;
        this.maxY = maxY;
        this.concreteImage = concreteImage;
    }

    @Override
    public String getColor(String name, int x, int y) {
        //У випадку, коли вхідна до методу координата не входить у необхідний проміжок - значення кольору не повертається
        System.out.println("getColor() " + this);
        if (x < minX || x > maxX || y < minY || y > maxY) {
            System.out.println("Access denied");
            return null;
        }
        return concreteImage.getColor(name, x, y);
    }
}
